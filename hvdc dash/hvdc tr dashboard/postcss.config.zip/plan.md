## Tests / Gates (SoT)

- [ ] gate: /diagnose env 출력 확인 (lockfile + scripts)
- [ ] gate: /validate 실행 (존재 스크립트만)
- [ ] gate: CI green (scripts 미존재 항목은 skip 로그 확인)

## Backlog

- [ ] SSOT 디렉토리 정리 (Ask-first)
- [ ] DeadlineLadder(문서 마감) SSOT/유틸/오버레이 분리 (opt-in rule 030 적용)
- [ ] ResourceTag/Conflict 탐지 유틸 (opt-in)
